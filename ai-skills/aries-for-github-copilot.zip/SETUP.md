# Aries skill library for GitHub Copilot

Unzip into the root of your Aries repo and commit. Copilot Chat in VS Code and on github.com reads `.github/copilot-instructions.md` automatically; it points to the reference files in `docs/ai/`. Mention a file with `#file:docs/ai/06-connectors.md` to pull it in directly.
