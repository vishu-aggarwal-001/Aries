# Aries skill library for Grok (Project)

## Setup
1. In Grok, create a **Project** named `Aries Skill Library`.
2. Paste all of `INSTRUCTIONS.txt` into the project's **custom instructions**.
3. Add every file in `knowledge/` to the project's files.
4. Start chats inside the project.

If projects aren't available to you, start a chat by uploading `ARIES_ALL_IN_ONE.md` and saying "Use this as your Aries skill library." 

## Files in this zip
- `INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
