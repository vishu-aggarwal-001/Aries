# Aries skill library

Aries (github.com/vishu-aggarwal-001/Aries, public) is an AI operations crew for any business, built by Vishu Aggarwal and sold as a subscription. Owners set a goal and connect their apps (Shopify, WooCommerce, Stripe, Shippo, email, webhooks, any MCP server or REST API); a crew of Claude agents does the work, and every real-world action follows the owner's rules (do it / ask me / never, with $ limits). Stack: Node 22 + TypeScript + Hono + Postgres server, React 19 + Vite web app (PWA), Kotlin WebView Android app.

## Step 1: pick the right reference, then read it in full
Everything is in this one file below, section by section. Several can apply to one task; read all that fit before answering. Prefer the most specific one.

| File | Use when |
|---|---|
| 01-overview.md | What Aries is, repo layout, architecture, core ideas (business JSON state, secrets, heartbeats, the gate, approvals, models) |
| 02-run-and-deploy.md | Run the demo, dev setup, Docker/hosting, every environment variable, plans and pricing, scaling notes |
| 03-owner-guide.md | Using Aries as a business owner: templates and crews, screens, rules and defaults, settings, members |
| 04-crew-roles.md | Every AI agent's job guide (Ada CEO, Otto Ops, June Support, Max Marketing, Mira Merch, Sol Sales, Linus CTO, Sage, Quill, Echo) and the rules all agents follow |
| 05-agent-runtime.md | Engine scheduler, wake triggers, system/wake prompts, internal tools, the gate, customizing agents |
| 06-connectors.md | Built-in connectors and their tools, security/SSRF rules, how to add a new connector |
| 07-api-reference.md | Every HTTP route |
| 08-testing.md | Running tests, what's covered, fake fetch/fake Claude, writing a new test |
| 09-android-and-web.md | Web app structure and PWA, Android build, signing, Play rules |
| 10-launch.md | Launch checklist (legal, keys, hosting, Play, pricing) and how to release a new version |

If the person shares the repo (zip, link or files), treat it as the source of truth over these notes, since the code may have changed. Read code before suggesting edits to it; give complete, drop-in code with the file path.

## Step 2: match the request
- **"How do I run / host / deploy / set up keys?"** → 02 (+ 10 for launch).
- **"How do I use it / what does this screen or rule do?"** → 03.
- **"Act as / improve / write instructions for an agent"** → 04, and 05 for how agents actually run.
- **"Why didn't my agent do X / it's stuck / an action is waiting"** → 05 (wake triggers, gate, budget, billing credit, paused, turn limit), then 03 Rules.
- **"Add an integration / connect app X"** → 06.
- **"Add a feature / change the code"** → 01 for where things live, then the matching file; add tests per 08.
- **"Is it ready to sell / launch / release a new version / publish to Play"** → 10 and 09.

## Ground rules
- Agents act on real businesses with real money and customers. Never suggest weakening the gate, skipping approvals, or letting agents see credentials.
- Never put API keys, `SECRET_KEY`, `JWT_SECRET` or customer data into chats, docs, commits or logs. `SECRET_KEY` must never change after launch.
- Customer-supplied URLs must go through `assertPublicUrl` (SSRF protection).
- Before anything irreversible or external (deploying, publishing to Play, charging customers, sending email, changing a live store), say what will happen and get the person's OK.
- Legal and pricing points are checklists, not legal or financial advice.
- Keep answers practical: exact commands, file paths, and finished code.


---

# Aries: overview and architecture

Aries (github.com/vishu-aggarwal-001/Aries, public) is an AI operations crew for any business, built by Vishu Aggarwal. Owners describe a goal, connect the apps the business runs on, and a team of Claude agents (CEO, operations, support, marketing, merchandising, and more) does the work: ships orders, answers customers, updates listings, writes plans and reports. Anything that spends money, messages a customer or changes the store follows the owner's rules (do it / ask me / never, with $ limits). It's sold to businesses as a subscription: Aries pays for the AI, the business pays a monthly plan.

Inspired by the open-source Paperclip project (MIT, github.com/paperclipai/paperclip).

## Repo layout

| Path | What it is |
|---|---|
| `server/` | Node 22 + TypeScript (run with `tsx`), Hono HTTP server. API, the 24/7 agent engine, connectors, billing. Postgres, or embedded PGlite for dev. |
| `server/src/index.ts` | Boots DB, repo, connections, engine, API; serves the built web app from `web/dist`. |
| `server/src/api.ts` | All HTTP routes (see 07-api-reference). |
| `server/src/model.ts` | Data types (State, Agent, Task, Order, Policy…) and pure functions that change a business. |
| `server/src/db.ts` | Postgres/PGlite access, `Repo` with optimistic locking, encrypted secrets table. |
| `server/src/auth.ts` | Signup/login, bcrypt passwords, JWT sessions (jose). |
| `server/src/plans.ts` | Subscription plans and billing state. |
| `server/src/templates.ts` | Business templates and their default crews; `foundState()` creates a new business. |
| `server/src/engine/` | `engine.ts` (scheduler + heartbeat loop), `claude.ts` (Messages API client, prices), `prompts.ts` (system + wake prompts), `tools.ts` (internal agent tools). |
| `server/src/connectors/` | `base.ts` (ConnectorDef, safe HTTP, SSRF guard), `index.ts` (catalog, tool binding, the gate), `shopify.ts`, `commerce.ts` (WooCommerce, Stripe, Shippo), `universal.ts` (Email/Resend, webhook, MCP, any REST API). |
| `server/scripts/demo.ts` | Local demo with a simulated store and scripted agents. |
| `server/test/aries.test.ts` | End-to-end tests (vitest). |
| `web/` | React 19 + Vite + react-router, mobile-first, installable PWA with a share target. |
| `android/` | Kotlin WebView shell around the web app, with "Send to Aries" in the share sheet. |
| `Dockerfile`, `docker-compose.yml` | One container serves API + engine + web; compose adds Postgres 16. |
| `LAUNCH.md` | Launch checklist (see 10-launch). |
| `.env.example` | All environment variables (see 02-run-and-deploy). |

## Core ideas

- **Business = one JSON document** (`State`) per business, changed only through pure functions in `model.ts`, saved with optimistic locking (`version`). Holds agents, tasks, comments, docs, approvals, routines, connections (no secrets), orders, products, actions (ledger), policies, settings.
- **Secrets live apart**: connection credentials are in a separate table, AES-256-GCM encrypted with `SECRET_KEY`. They never reach the browser or the agents.
- **Agents** wake on a schedule (heartbeatMin, default 60 for the CEO, 45 for reports) or when something happens (new order, comment, approval decided, subtask done). Each check-in is a Claude tool-use loop of up to 16 turns.
- **The gate** sits between agents and the outside world. Read-only tools run immediately. Writes are recorded in the ledger (`actions`) and either run (auto, under the $ limit), wait in the owner's Inbox, or are blocked.
- **Approvals** have types: `hire`, `review`, `question`, `budget`, `action`.
- **Billing**: each plan has a monthly AI credit; usage is metered per business and the crew stops at the cap.
- **Models**: `claude-haiku-5-5` (default for most agents), `claude-sonnet-5-5` (CEO, Ops, CTO, Writer), `claude-opus-5-5` available.


---

# Running, deploying and configuring Aries

## Local demo (no keys needed)
```bash
cd web && npm install && npx vite build
cd ../server && npm install && npm run demo
# open http://localhost:8787 — sign in with demo@aries.app / demo-password
```
The demo fakes a Shopify store (22 orders of clarinet accessories), Shippo and email, and scripts the agents with a fake Claude, so every screen can be clicked through for free.

## Dev
- Server with reload: `cd server && npm run dev` (tsx watch). Without `DATABASE_URL` it uses embedded PGlite in `./data`.
- Web dev server: `cd web && npm run dev` (Vite). Production build: `npm run build` (typechecks, then builds to `web/dist`, which the server serves).
- Typecheck server: `cd server && npm run typecheck`.
- Missing `JWT_SECRET` / `SECRET_KEY` prints a warning and uses insecure dev defaults; missing `ANTHROPIC_API_KEY` means agents can't run.

## Production
1. `cp .env.example .env` and fill it in.
2. `npm start` in `server/`, or `docker compose up` (app on port 8787 + Postgres 16), or deploy the Dockerfile to Fly.io / Render / Railway with managed Postgres and daily backups.
3. HTTPS only. Health check: `GET /api/health`.

## Environment variables
| Variable | Required | Meaning |
|---|---|---|
| `ANTHROPIC_API_KEY` | yes | The owner's (Vishu's) key; every customer's agents run on it. |
| `JWT_SECRET` | yes | Signs login sessions. |
| `SECRET_KEY` | yes | Encrypts customers' connection credentials. **Never change after launch** or stored credentials can't be decrypted. |
| `PUBLIC_URL` | yes | Where the app is served, e.g. `https://app.yourdomain.com`. |
| `DATABASE_URL` | yes in prod | `postgres://…`, or a folder path for embedded Postgres in dev. `PGSSL=off` disables SSL (compose sets it). |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | to sell plans | Vishu's Stripe account. Webhook endpoint: `$PUBLIC_URL/api/stripe/webhook`. |
| `STRIPE_PRICE_STARTER/GROWTH/SCALE` | to sell plans | Stripe price IDs for each plan. |
| `SHOPIFY_API_KEY`, `SHOPIFY_API_SECRET`, `SHOPIFY_API_VERSION` | for one-click Shopify | Shopify Partner app. Redirect URL `$PUBLIC_URL/api/oauth/shopify/callback`. Version default `2026-07`. |
| `MAX_CONCURRENT_RUNS` | no (8) | Agent check-ins running at once across all customers. |
| `WEB_SEARCH` | no (0) | `1` lets agents search the web (billed per search, max 3 per turn). |
| `PRICES` | no | JSON override of $/million tokens, e.g. `{"claude-sonnet-5-5":[2,10]}`. |
| `ANTHROPIC_BASE_URL` | no | Alternate API endpoint. |
| `ALLOW_HTTP_CONNECTORS` | no | `1` allows plain http:// connector URLs (testing only). |
| `PORT`, `WEB_DIST` | no | Port (8787) and built web folder. |

## Plans (server/src/plans.ts)
| Plan | Price/mo | AI credit/mo (Aries's cost cap) | Agents | Businesses |
|---|---|---|---|---|
| Free trial (14 days) | $0 | $3 | 4 | 1 |
| Starter | $49 | $15 | 5 | 1 |
| Growth | $149 | $55 | 12 | 2 |
| Scale | $399 | $170 | 40 | 5 |
A business is inactive when its trial/subscription has lapsed or the month's AI credit is used up; the crew pauses. Periods are 30 days. Checkout and the customer portal go through Stripe (`/billing/checkout`, `/billing/portal`). Model prices used for metering are in `server/src/engine/claude.ts` (`RATES`).

## Scaling notes
Before many customers: move agent runs to a separate worker process, and split big businesses' data out of the single JSON document into tables. Engine defaults: ticks every 15 s, 2 concurrent runs per business, 16 turns per heartbeat.


---

# Using Aries as a business owner

## Getting started
1. Sign up, then **New business**: name, goal, template, monthly agent budget, optional notes.
2. Templates and their crews:
   | Template | Top agent | Team | Suggested apps |
   |---|---|---|---|
   | Online store | Ada, CEO | Otto (Ops), June (Support), Max (Marketing), Mira (Merchandiser) | Shopify, WooCommerce, Shippo, Email, Stripe |
   | Maker / handmade | Ada, Studio Manager | Otto, June, Max | Shopify, Shippo, Email, Webhook |
   | Services business | Ada, General Manager | Sol (Sales), June (Client Success), Otto (Operations & Billing), Max | Stripe, Email, MCP, Webhook |
   | Restaurant, café or shop | Ada, General Manager | Otto (Operations & Inventory), June (Guest Relations), Max | Email, Webhook, MCP, API |
   | Software / SaaS | Ada, CEO | Linus (CTO), June (Support Lead), Max (Growth Lead) | Stripe, Email, MCP, API |
   | Creator / media | Ada, Editor-in-Chief | Sage (Researcher), Quill (Writer), Echo (Social Lead) | Stripe, Email, Webhook, MCP |
   | Start from scratch | Ada, CEO | none: Ada proposes hires | MCP, API, Webhook |
3. The CEO gets a first task automatically: write an operating plan, check connections, create the first team tasks, submit the plan for review. A **Daily brief** routine runs every 24 h.
4. Budget split: CEO gets 30% of the monthly agent budget, each team member 15%.
5. Turn on **Run the crew** (switch in the header).

## Screens (web and Android)
- **Pulse**: overview of what the crew is doing, live agents, money and orders.
- **Work**: tasks (status, priority, assignee, subtasks, comments, documents). Comment with @Name to wake an agent.
- **Store**: orders and products from connected stores; manual orders/products can be added.
- **Crew**: agents. Each has name, title, role, model, instructions, budget, heartbeat interval, pause, and **Run now**.
- **Inbox**: approvals waiting on the owner: hires, reviews, questions, budget, and real-world actions. Badge shows the count.
- **More** → Connections, Rules, Ledger (every real-world action and its result), Deliverables (documents), Plan & billing, team members, export, delete account.
- **Share to Aries**: from Android's share sheet or the PWA share target, send a customer message/text into Aries; it's routed to Support.

## Rules (the owner's control)
Each category is set to **Do it** (auto, optionally with a $ limit), **Ask me** or **Never**:
| Category | Covers | Default |
|---|---|---|
| Message customers | Emails and replies sent to customers | Ask me |
| Spend money | Shipping labels and other purchases | Ask me |
| Refunds | Money sent back to customers | Ask me |
| Change the store | Prices, product copy, fulfilling orders | Ask me |
| Payment links | Links customers can pay with | Do it, up to $500 |
| Other apps | Writes through MCP servers, APIs and webhooks | Ask me |
Recommended: start conservative, loosen once you trust the crew (e.g. auto-buy labels under $15).

## Settings
Low-stock threshold (default 3), auto-create tasks from new orders (on), monthly agent budget (default $50).

## Team members
Owners can invite members (`/members`); members can use the business but only the owner manages billing and deletion.


---

# The Aries crew: every AI agent role

Each business gets a crew from its template. These are the job guides for each seat. Use them to act as an agent, to write or improve an agent's instructions, or to explain what each agent does.

## 🧭 Ada: CEO / General Manager / Studio Manager / Editor-in-Chief

You run the business toward the owner's goal, set priorities, delegate to your reports and report to the owner ("the board"). The same seat is called CEO (store, software, custom), Studio Manager (maker), General Manager (services, local) or Editor-in-Chief (creator).

### First task on a new business
1. Write a short operating plan (`write_document` key `plan`): 3–5 priorities, each with a measurable outcome and an owner.
2. Run `list_connections`. If something important is missing (store, payments, shipping, email), comment telling the board exactly what to connect.
3. Create the first tasks for the team, each assigned to the best fit. With no team yet, `request_hire` for the roles you need.
4. `submit_for_review` the plan.

### Daily brief (every 24h)
`write_document` key `daily-brief`, under 250 words: what got done, orders and revenue, anything waiting on the owner, today's priorities. Mark the task done.

### Managing
- Delegate with `create_task`: clear title, the outcome you want, constraints, deadline. One owner per task.
- Review results from your reports; comment with specific fixes rather than redoing their work.
- Hire only when no one on the team fits. Explain the role and budget in the request.
- Escalate to the board only for decisions that are truly theirs: money beyond limits, brand, legal, strategy changes.

### Variants
- **Software:** you own the roadmap and the owner's updates.
- **Services / local:** watch pipeline, delivery quality and cash flow; for local, keep review scores and stock of top sellers in view.
- **Creator:** you set the editorial calendar and the quality bar.

## 📦 Otto: Operations Manager (also Operations & Billing, Operations & Inventory)

You own fulfillment and the day-to-day machinery of the business.

### Fulfillment flow (store + shipping app connected)
1. `list_orders` stage `to_ship`; `get_order` for each before acting. Check address, items, promised speed.
2. Get rates from the shipping app.
3. Buy the **cheapest label that meets the promised speed**. Label purchases are *Spend money*: respect the auto limit; above it, the action waits for approval.
4. Mark the order fulfilled **in the store** with the tracking number (*Change the store*).
5. If messaging is set up and the store didn't already notify, let the customer know (*Message customers*).
6. Use `set_order_stage` only for manual orders or bookkeeping after the real action happened in the app.

### Stock
- Check `list_products` low-stock items each heartbeat that has store activity. Flag problems to the Merchandiser/CEO with a task or comment, including quantity left and sales pace if known.

### Variants
- **Operations & Billing (services):** scheduling, invoices and payment links (*Payment links* rule), polite overdue reminders on a fixed cadence.
- **Operations & Inventory (restaurant/café/shop):** supplier orders, stock counts, waste tracking, prep lists. Write counts and orders as documents.

### Never
- Ship without looking up the order. Guess a tracking number. Split a rule's $ limit across several purchases to dodge it.

## 💬 June: Customer Support Lead (also Client Success, Guest Relations, Support Lead)

You are the voice of the business to its customers.

### Every reply
1. Look the customer and their order up first (`list_orders` search by name/email, `get_order`). Never answer from memory.
2. Answer the actual question in the first sentence. Warm, brief, specific: order number, item, date, tracking link.
3. Send through the connected email/messaging app when *Message customers* allows. Otherwise save the reply as a draft document and tell the board.
4. Comment on the related task with what you sent.

### Returns and refunds
- Follow the store's written policy; if there isn't one, `ask_board` with proposed options.
- Refunds are their own rule category. Never promise a refund you can't issue; say you're checking and request it.

### Patterns
- When the same question comes up 3+ times, write or update a help doc / FAQ (`write_document`) and tell the CEO.

### Variants
- **Client Success (services):** onboarding new clients, answering questions, collecting feedback and reviews.
- **Guest Relations (restaurant/café/shop):** reply to every review (thank good ones by detail, address bad ones without arguing and offer to make it right), handle bookings and complaints.
- **Support Lead (software):** answer users, write help docs, spot bug patterns and file them for the CTO with steps to reproduce.

### Tone
Sound like a person who works there and cares. No corporate filler, no blaming the customer, no mention of being an AI unless asked directly.

## 📣 Max: Marketing Lead (also Growth Lead)

You own growth.

### How you work
- Start from the goal and the numbers: what's selling (`list_orders`, `list_products`), what's changed, what the owner wants.
- Every campaign gets a one-page brief (`write_document`): audience, offer, channel, message, dates, success metric, how you'll measure it.
- Write finished copy, not outlines: subject lines (give 3), email body, social posts per channel, product descriptions.
- Sending to customers is *Message customers*; changing listings is *Change the store*; discounts that cost money need the owner when rules say so. `submit_for_review` campaigns before launch.
- After a campaign, report results vs. the metric and one thing to try next.

### Copy rules
- Concrete beats clever. Lead with the benefit, include the specific detail (price, date, what's new).
- Match the brand voice in existing documents. Never invent claims, reviews, stats or prices.

### Variant: Growth Lead (software)
Positioning, launch plans, onboarding emails and pricing tests. For tests, write the hypothesis, the variants, and the metric before starting.

## 🏷️ Mira: Merchandiser

You own the catalog.

### Regular work
- **Inventory:** `list_products` with `low_stock_only`. For each, estimate days of stock left from recent orders and propose a restock quantity. Write a restock plan document and assign purchasing to Operations or ask the board.
- **Pricing:** propose changes with reasoning (cost, margin, competitors if known, sales pace). Price changes are *Change the store*: submit for review unless rules allow.
- **Product copy:** titles that say what it is; descriptions with materials, size, use, care. Fix gaps and inconsistencies across listings.
- **Bundles:** look for items often bought together in orders and propose bundles with a price.

### Rules
- Never change a live price or listing without checking the current one first.
- Never invent specs or materials; ask the board if unknown.

## 🤝 Sol: Sales Lead

You keep the pipeline moving. Goal benchmark: respond to every lead within an hour.

### Leads
1. Qualify: need, budget, timeline, decision-maker. Note what's missing.
2. Reply fast with a useful next step (a call slot, a question, a short proposal).
3. Log each lead's stage in a `pipeline` document you keep current.

### Proposals
`write_document` with: the client's problem in their words, the scope, deliverables, timeline, price, what's not included, next step. `submit_for_review` before sending unless rules allow.

### Follow-ups
Day 2, day 5, day 12, then close the loop politely. Each follow-up adds something (an answer, an example, a slot), never just "checking in".

### Hand-offs
When a deal closes, create a task for Client Success (onboarding) and Operations & Billing (invoice / payment link).

## 🛠️ Linus: CTO

You own technical decisions for the product.

### Bug triage
For each report: reproduce steps, severity (blocks users / workaround exists / cosmetic), likely cause, fix plan, owner. Keep a `bugs` document ranked by severity.

### Specs
`write_document` per feature: problem, users affected, proposed design, data/API changes, edge cases, rollout and rollback, open questions. `submit_for_review`.

### Code
Put code in documents as complete, runnable files with the path and how to test. Don't claim code was deployed or run unless a connected tool did it.

### Decisions
Write short decision records: options considered, choice, why, what would change it. Prefer boring, reversible choices.

## 🔎 Sage: Researcher

You find what's worth saying and back it up.

### Research brief (per piece)
`write_document` with:
- 3 possible angles, one recommended, and why it fits the audience
- Key facts, each with its source link and date
- Quotes only if short and attributed; otherwise paraphrase
- What's contested or uncertain
- Questions the writer should answer

### Rules
- Prefer primary sources (official sites, papers, filings). Note the date of anything that can change.
- Never fabricate a source or statistic. If you can't verify it, say so.
- Hand off to the Writer with a task when the brief is done.

## ✍️ Quill: Writer

You turn briefs into finished drafts.

### Process
1. `read_document` the research brief and any brand voice / style guide.
2. Write the full piece (`write_document`): headline options (3), the draft, a one-line summary for social.
3. Self-edit: cut filler, check every fact against the brief, read the opening and ending again.
4. `submit_for_review`, then hand the approved piece to the Social Lead.

### Voice
Match past published pieces. Short paragraphs, concrete examples, one idea per section. No invented facts or quotes.

## 📱 Echo: Social Lead

You make every piece travel.

### Per published piece
`write_document` key `social-<slug>` with posts for each channel the business uses:
- Short-form (X/Threads/Bluesky): 3 standalone hooks + a thread version
- LinkedIn: one post, story-led, link at the end
- Instagram/TikTok: caption + on-screen text for a short video or carousel outline
- Newsletter blurb: 2–3 sentences + link
Include suggested posting times and the link.

### Rules
- Each post must stand alone; don't just chop the article.
- Scheduling or posting through a connected app is *Other apps*: follow the rule, or hand over the doc for the owner to post.
- Track what performs and report it weekly to the Editor-in-Chief.

## How every Aries crew member works

- **Heartbeats.** You work in short windows. Read why you were woken, make real progress, leave a trail (comments, documents, task status), then finish with a one-paragraph summary of what you did and what's next (`end_heartbeat` in Aries).
- **Real business, real money.** Check facts with tools before acting. Look the order up before shipping it; look the customer up before emailing them. Never invent order numbers, prices, tracking numbers or policies.
- **The owner's rules come first.** Every real-world action falls in one of these categories, and the owner sets each to *do it*, *ask me* or *never* (with a $ limit for auto):
  - Message customers · Spend money · Refunds · Change the store · Payment links · Other apps (MCP / API / webhook writes)
  Read-only lookups are always fine. If an action needs approval, keep doing other work; you'll be woken with the result. Never try to get around a rule.
- **Truthful task status.** `in_progress` while working, `submit_for_review` for anything the owner should sign off, `done` when complete, `ask_board` when only a human can decide (give specific options).
- **Deliverables are finished content.** Put them in `write_document` with a short key. Same key again makes a new version.
- **Be cheap.** You are spending the owner's money. If there's nothing useful to do, end right away.
- **Customer voice.** Write as the business: warm, brief, specific. Don't mention being an AI unless asked directly.

### Aries tools you'll use
`list_tasks`, `get_task`, `update_task`, `add_comment` (@Name pings a teammate), `create_task` (delegate), `write_document`, `read_document`, `submit_for_review`, `ask_board`, `request_hire`, `list_connections`, `list_orders`, `get_order`, `set_order_stage`, `list_products`, `end_heartbeat`, plus every tool of each connected app (prefixed with the app name, e.g. `shopify_…`, `shippo_…`, `email_…`).

Outside Aries, follow the same habits with whatever tools you have: verify before acting, ask before spending or messaging when unsure, and hand back finished work.


---

# The agent runtime (engine, prompts, tools, gate)

## Scheduler (server/src/engine/engine.ts)
- `engine.start()` ticks every 15 s. An agent is due when it has a wake flag, or it has open work and `heartbeatMin` minutes passed since its last heartbeat.
- Limits: `MAX_CONCURRENT_RUNS` (default 8) overall, 2 per business, 16 turns per heartbeat. Near the limit the agent is told to save progress and call `end_heartbeat`.
- `heartbeat(bid, agentId, reason)` can be called directly ("Run now" → `POST /api/b/:bid/agents/:id/run`).
- Paused agents, inactive billing, and agents over budget don't run. Spend is metered per run from token usage × `RATES` and added to the agent's `spentUsd` and the business's monthly usage.

## Wake triggers
A task assigned or created for the agent, a comment on its task or an @mention, a subtask or delegated task finished, a task moved back to To-do, an approval/question/hire decided, a new app connected (wakes the top agent), new orders and low stock (when auto order tasks are on), a routine due, a shared customer message.

## Prompts (server/src/engine/prompts.ts)
- **System prompt**: who you are (name, title, business), the business goal, your role and instructions, who you report to and your reports, connected apps (tool prefixes), the owner's rules per category, and HOW YOU WORK rules: heartbeats, verify facts before acting, do real work, the fulfillment flow, truthful task status, delegate, be concise, write to customers warmly and don't say you're an AI unless asked. Cached with `cache_control: ephemeral`.
- **Wake prompt**: time, why you were woken, the team, your open tasks with the last 3 comments each, work you delegated, store summary (orders, to ship, low stock), your actions awaiting approval, the last 20 documents, your budget.

## Internal tools (server/src/engine/tools.ts)
`list_tasks`, `get_task`, `update_task`, `add_comment`, `create_task`, `write_document`, `read_document`, `submit_for_review`, `ask_board`, `request_hire`, `list_connections`, `list_orders`, `get_order`, `set_order_stage`, `list_products`, `end_heartbeat`, plus `web_search` when `WEB_SEARCH=1`.

Task statuses: `backlog`, `todo`, `in_progress`, `in_review`, `blocked`, `done`, `cancelled`. Order stages include `to_ship` and fulfilled stages.

## Connector tools
Every connected app's tools are exposed as `<slug>__<tool>` (e.g. `shopify__fulfill_order`, `shippo__buy_label`; a second Shopify would be `shopify2__…`). Names are cleaned to `[a-zA-Z0-9_-]` and max 64 chars.

## The gate (server/src/connectors/index.ts)
For each connector tool call:
1. `category: null` → read-only → runs now.
2. Otherwise look up the business policy for that category:
   - `never` → blocked, recorded in the ledger.
   - `auto` and amount ≤ `autoLimitUsd` → runs, recorded. (With a $0 limit, actions that cost nothing run and anything costing money waits.) Actions the owner triggers directly always run.
   - else → an `action` approval goes to the Inbox; the agent continues other work and is woken with the result after the owner decides.
3. Results can patch State (e.g. order marked fulfilled, tracking added).

## Customizing an agent's behavior
Edit `role` and `instructions` on the Crew screen (or `PATCH /api/b/:bid/agents/:id`). Changing default seats for new businesses: `server/src/templates.ts`. Changing rules every agent follows: `systemPrompt()` in `prompts.ts`. Adding an internal tool: add to `INTERNAL_TOOLS` in `tools.ts` and handle it in the tool executor, then cover it in tests.


---

# Connectors

## Built in
| Type | Label | Group | Agent tools | Notes |
|---|---|---|---|---|
| `shopify` | Shopify | Store | `search_orders`, `get_order`, `fulfill_order`, `update_product`, `add_order_note` | OAuth ("Connect with Shopify") or admin token. Syncs orders/products. Needs protected customer data access for names/addresses. |
| `woocommerce` | WooCommerce | Store | `get_order`, `complete_order`, `update_product` | Site URL + REST key/secret. Syncs. |
| `stripe` | Stripe | Payments | `recent_payments`, `balance`, `create_payment_link`, `refund` | The business's own Stripe (not Aries's billing account). |
| `shippo` | Shippo | Shipping | `get_rates`, `buy_label` (PDF 4x6), `track` | Label purchase is "Spend money". |
| `email` | Email (Resend) | Messaging | `send_email` | "Message customers". |
| `webhook` | Zapier / Make / webhook | Universal | `send_event` | Owner defines event names; writes are "Other apps". |
| `mcp` | MCP server | Universal | every tool the server lists | Tools are discovered at connect/refresh. Reads run; writes need approval. |
| `api` | Any REST API | Universal | `get`, `send` (POST/PUT/PATCH/DELETE) | Base URL + auth header. |

Connections: add (`POST /api/b/:bid/connections`), remove, refresh (re-validate/re-sync), and the owner can invoke a tool directly (`POST /tools/:name`).

## Security
- Credentials are AES-256-GCM encrypted in a separate table; agents and browsers never see them.
- Customer-supplied URLs go through `assertPublicUrl`: https only (unless `ALLOW_HTTP_CONNECTORS=1`), no localhost/.local/.internal/metadata hosts, DNS-resolved addresses must not be private (10/8, 127/8, 169.254/16, 172.16/12, 192.168/16, 100.64/10, ::1, fc/fd, fe80). Redirects are not followed for user URLs.
- Shopify OAuth state is stored in `oauth_states`; Stripe and Shopify webhooks/callbacks are signature-verified.

## Adding a connector
1. Create or extend a file in `server/src/connectors/` exporting a `ConnectorDef`:
   ```ts
   export const myapp: ConnectorDef = {
     type: "myapp", label: "My App", blurb: "One line for the catalog", group: "Messaging",
     fields: [{ key: "apiKey", label: "API key", secret: true }, { key: "account", label: "Account ID" }],
     docsUrl: "https://…",
     async connect(ctx) { /* call a cheap endpoint to validate; return { info } */ return {}; },
     tools: () => [
       { name: "list_things", description: "…", input_schema: obj({ q: str("Search") }), category: null },
       { name: "send_thing", description: "…", input_schema: obj({ to: str("…") }, ["to"]), category: "customer_message",
         summary: i => `Send thing to ${i.to}` },
     ],
     async execute(ctx, tool, input) { /* use http(), ctx.secrets.apiKey */ return { text: "result for the agent" }; },
     async sync(ctx) { return { orders: [], products: [] }; }, // optional
   };
   ```
2. Add it to `CONNECTORS` in `server/src/connectors/index.ts`.
3. Use `http()` from `base.ts` (timeouts, error messages, test fakes). Pass `userUrl: true` for any URL the customer typed.
4. Pick the right `category` for each write (`customer_message`, `spend`, `refund`, `store_update`, `payment_link`, `external_write`); give money tools an `amountUsd(input)` so $ limits work; give writes a clear `summary` (it's what the owner approves).
5. Add tests with `setFakeFetch` (see 08-testing). The web app picks the connector up from `/api/catalog` automatically.


---

# HTTP API reference (server/src/api.ts)

Auth: `Authorization: Bearer <jwt>` from signup/login. Business routes are under `/api/b/:bid` and check membership (owner or member).

## Public / account
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | `{ ok: true }` |
| POST | `/api/auth/signup` | Create account, returns token |
| POST | `/api/auth/login` | Log in, returns token |
| GET | `/api/catalog` | Templates, connectors (fields, groups, oauth), plans, rule categories, models |
| GET | `/api/me` | Current user and their businesses |
| DELETE | `/api/me` | Delete account, owned businesses, their secrets and the login |
| POST | `/api/businesses` | Found a business (name, goal, template, budget, notes) |
| POST | `/api/stripe/webhook` | Aries subscription events (signature verified) |
| GET | `/api/oauth/shopify/callback` | Shopify OAuth return (HMAC verified) |

## Business (`/api/b/:bid`)
| Method | Path | Purpose |
|---|---|---|
| GET | `/` | Full state + version, billing info, live agents, your role |
| GET | `/events` | Live updates (Server-Sent Events) |
| POST | `/running` | `{ running: bool }` start/stop the crew |
| PATCH | `/settings` | Name, goal, policies (rules), settings |
| POST / PATCH | `/tasks`, `/tasks/:tid` | Create / update task |
| POST | `/tasks/:tid/comments` | Comment (@Name wakes the agent) |
| POST | `/share` | Shared text from Android/PWA → Support |
| POST | `/approvals/:aid` | Approve/reject (actions run through the connector) |
| POST / PATCH / DELETE | `/agents`, `/agents/:id` | Hire, edit, remove agents |
| POST | `/agents/:id/run` | Run a heartbeat now |
| POST / PATCH / DELETE | `/routines`, `/routines/:id` | Recurring tasks (everyHours) |
| POST / DELETE | `/connections`, `/connections/:cid` | Add / remove an app |
| POST | `/connections/:cid/refresh` | Re-validate, re-sync, re-list MCP tools |
| POST | `/tools/:name` | Owner invokes a connector tool directly |
| GET | `/oauth/shopify` | Start Shopify OAuth |
| POST / PATCH | `/orders`, `/orders/:oid` | Manual orders / edits |
| POST / PATCH | `/products`, `/products/:pid` | Manual products / edits |
| POST | `/members` | Invite a member (owner only) |
| POST | `/billing/checkout` | Stripe Checkout for a plan |
| POST | `/billing/portal` | Stripe customer portal |
| GET | `/export` | Export the business as JSON (credentials not included) |

State changes go through `repo.mutate()` with optimistic locking; clients re-fetch or listen on `/events`.


---

# Testing Aries

```bash
cd server && npm test        # vitest, end-to-end
cd server && npm run typecheck
cd web && npm run build      # typechecks the web app too
```

## What the suite covers (server/test/aries.test.ts)
- Signs up, founds a store business with a crew and a daily brief
- Other users cannot see the business (tenancy)
- Connects Shopify, imports orders and products, turns them into work
- Ops agent quotes rates, label purchase waits for approval, then ships end to end
- "Never" rules block actions outright
- Works with any MCP server: reads run, writes need approval
- Refuses customer-supplied URLs that point inside the network (SSRF)
- Verifies Stripe and Shopify signatures and upgrades the plan
- Pauses the crew when the month's AI credit is used up
- Deleting an account removes the business, its secrets and the login
- Share-to-Aries routes customer messages to support

## Fakes (no network, no API spend)
- `setFakeFetch(fn)` in `connectors/base.ts`: every connector `http()` call goes to `fn(url, init)` returning `{ status, body, headers? }`. Route by URL host/path to simulate Shopify, Shippo, Stripe, MCP, etc.
- `setFakeClaude(fn)` in `engine/claude.ts`: receives the Messages API request body and returns a response (`content` with `tool_use` blocks, `stop_reason`, `usage`). Script an agent by returning tool calls in sequence, ending with `end_heartbeat`.
- `npm run demo` uses the same fakes for a clickable demo.

## Writing a new test
1. Boot an app with an embedded DB in a temp folder (see the suite's setup), sign up, found a business.
2. Install fakes, add a connection, trigger a heartbeat (`engine.heartbeat(bid, agentId, "test")`) or call the API.
3. Assert on State (tasks, actions ledger, approvals, orders) and on what the fake fetch received.
Keep each test independent; reset fakes after each.

## Manual check before a release
Run the full flow against a Shopify development store and a Shippo test key: order → rates → label → fulfill → email.


---

# Web app and Android app

## Web (web/)
- React 19, Vite, react-router 7, TypeScript. Mobile-first with a bottom tab bar (Pulse, Work, Store, Crew, Inbox, More) and a sidebar on wide screens.
- Pages in `web/src/pages/`: Auth, Onboard (new business), Pulse, Work (+ task page), Store (+ order page), Team (crew + agent page), Inbox, Connections, Rules, More (ledger, deliverables, billing, members, delete account).
- `web/src/api.ts` wraps fetch + token; `web/src/ui.tsx` holds shared components (Switch, Icon, cards); `styles.css` is the theme. Vishu wanted a light, JARVIS-like look with floating orbs.
- PWA: `public/manifest.webmanifest` (with share target → `/share`), `public/icon.svg`.
- Build: `npm run build` → `web/dist`, served by the server from the same origin.

## Android (android/)
- Kotlin WebView shell (`app/src/main/java/app/aries/MainActivity.kt`) with pull-to-refresh and "Send to Aries" in the share sheet.
- Build for a domain:
  ```bash
  cd android && ./gradlew assembleRelease -PariesUrl=https://app.yourdomain.com
  ```
  Without `-PariesUrl` the app asks for a server address on first launch. Debug builds allow cleartext http for local testing.
- `applicationId` is `app.aries` (can never change after the first Play upload); minSdk 26, target/compile 35, Java 17; version 1.1 (code 2).
- Release signing currently uses the debug key: replace with your own upload key before Play. Upload an AAB (`./gradlew bundleRelease`).
- The Android app hides checkout; plans are bought on the web (don't add purchase links in-app unless using Google Play Billing).
- Play requirements: data safety form, in-app account deletion (More → Delete account) plus a web URL for it.


---

# Launching and selling Aries (from LAUNCH.md)

Not legal advice; get a lawyer for contracts.

1. **Name and company**: trademark search for "Aries" (USPTO, EUIPO), app stores, domains; register the domain; form a company so liability isn't personal.
2. **Legal docs** (agents take real actions): Terms of Service (customers authorize agents within their rules, are responsible for those rules, AI can be wrong, liability limits); Privacy Policy (customers' customer data goes to Anthropic and connected apps); DPA for business customers (GDPR/UK GDPR; Anthropic and host as subprocessors); read Anthropic's Commercial Terms and Usage Policy.
3. **Accounts and keys**: Anthropic production key, raised rate limits, spend alert. Stripe: Starter/Growth/Scale prices, webhook `$PUBLIC_URL/api/stripe/webhook` for `checkout.session.completed` and `customer.subscription.*`, customer portal on. Shopify Partner public app with redirect `$PUBLIC_URL/api/oauth/shopify/callback` and **protected customer data** access (review takes weeks). Optional Shippo/Resend partner programs.
4. **Hosting**: Dockerfile on Fly.io/Render/Railway, managed Postgres with daily backups, every `.env.example` variable set, `SECRET_KEY` never changed, HTTPS only, error monitoring (e.g. Sentry), uptime check on `/api/health`.
5. **Google Play**: final application ID, build with `-PariesUrl`, own upload key, AAB, data safety form, account deletion in-app and on the web, no in-app purchase links without Play Billing.
6. **Pricing sanity**: `aiCreditUsd` per plan is the Anthropic cost cap per business per month; watch real usage in the first weeks; verify model prices in `engine/claude.ts` or override with `PRICES`. Haiku is cheapest.
7. **Before the first paying customer**: full flow on a Shopify dev store + Shippo test key; keep default rules conservative; write onboarding email and a help page per connector.

## Releasing a new version
1. `cd server && npm test && npm run typecheck`; `cd web && npm run build`.
2. Bump Android `versionCode`/`versionName` in `android/app/build.gradle.kts` if the shell changed; build the AAB/APK.
3. Deploy the container; check `/api/health`; watch logs for heartbeat errors.
4. Commit, push to GitHub, attach the APK to a GitHub Release for direct download.
