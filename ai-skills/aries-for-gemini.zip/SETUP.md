# Aries skill library for Gemini (Gem)

## Setup
1. In Gemini, open **Gems → New Gem**.
2. Name: `Aries Skill Library`.
3. Paste all of `GEM_INSTRUCTIONS.txt` into **Instructions**.
4. Under **Knowledge**, add every file in `knowledge/` (or just `ARIES_ALL_IN_ONE.md` if it limits the number of files).
5. Save.

## Files in this zip
- `GEM_INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
