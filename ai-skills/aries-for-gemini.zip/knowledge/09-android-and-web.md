# Web app and Android app

## Web (web/)
- React 19, Vite, react-router 7, TypeScript. Mobile-first with a bottom tab bar (Pulse, Work, Store, Crew, Inbox, More) and a sidebar on wide screens.
- Pages in `web/src/pages/`: Auth, Onboard (new business), Pulse, Work (+ task page), Store (+ order page), Team (crew + agent page), Inbox, Connections, Rules, More (ledger, deliverables, billing, members, delete account).
- `web/src/api.ts` wraps fetch + token; `web/src/ui.tsx` holds shared components (Switch, Icon, cards); `styles.css` is the theme. Vishu wanted a light, JARVIS-like look with floating orbs.
- PWA: `public/manifest.webmanifest` (with share target → `/share`), `public/icon.svg`.
- Build: `npm run build` → `web/dist`, served by the server from the same origin.

## Android (android/)
- Kotlin WebView shell (`app/src/main/java/app/aries/MainActivity.kt`) with pull-to-refresh and "Send to Aries" in the share sheet.
- Build for a domain:
  ```bash
  cd android && ./gradlew assembleRelease -PariesUrl=https://app.yourdomain.com
  ```
  Without `-PariesUrl` the app asks for a server address on first launch. Debug builds allow cleartext http for local testing.
- `applicationId` is `app.aries` (can never change after the first Play upload); minSdk 26, target/compile 35, Java 17; version 1.1 (code 2).
- Release signing currently uses the debug key: replace with your own upload key before Play. Upload an AAB (`./gradlew bundleRelease`).
- The Android app hides checkout; plans are bought on the web (don't add purchase links in-app unless using Google Play Billing).
- Play requirements: data safety form, in-app account deletion (More → Delete account) plus a web URL for it.
