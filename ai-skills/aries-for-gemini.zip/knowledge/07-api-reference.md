# HTTP API reference (server/src/api.ts)

Auth: `Authorization: Bearer <jwt>` from signup/login. Business routes are under `/api/b/:bid` and check membership (owner or member).

## Public / account
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | `{ ok: true }` |
| POST | `/api/auth/signup` | Create account, returns token |
| POST | `/api/auth/login` | Log in, returns token |
| GET | `/api/catalog` | Templates, connectors (fields, groups, oauth), plans, rule categories, models |
| GET | `/api/me` | Current user and their businesses |
| DELETE | `/api/me` | Delete account, owned businesses, their secrets and the login |
| POST | `/api/businesses` | Found a business (name, goal, template, budget, notes) |
| POST | `/api/stripe/webhook` | Aries subscription events (signature verified) |
| GET | `/api/oauth/shopify/callback` | Shopify OAuth return (HMAC verified) |

## Business (`/api/b/:bid`)
| Method | Path | Purpose |
|---|---|---|
| GET | `/` | Full state + version, billing info, live agents, your role |
| GET | `/events` | Live updates (Server-Sent Events) |
| POST | `/running` | `{ running: bool }` start/stop the crew |
| PATCH | `/settings` | Name, goal, policies (rules), settings |
| POST / PATCH | `/tasks`, `/tasks/:tid` | Create / update task |
| POST | `/tasks/:tid/comments` | Comment (@Name wakes the agent) |
| POST | `/share` | Shared text from Android/PWA → Support |
| POST | `/approvals/:aid` | Approve/reject (actions run through the connector) |
| POST / PATCH / DELETE | `/agents`, `/agents/:id` | Hire, edit, remove agents |
| POST | `/agents/:id/run` | Run a heartbeat now |
| POST / PATCH / DELETE | `/routines`, `/routines/:id` | Recurring tasks (everyHours) |
| POST / DELETE | `/connections`, `/connections/:cid` | Add / remove an app |
| POST | `/connections/:cid/refresh` | Re-validate, re-sync, re-list MCP tools |
| POST | `/tools/:name` | Owner invokes a connector tool directly |
| GET | `/oauth/shopify` | Start Shopify OAuth |
| POST / PATCH | `/orders`, `/orders/:oid` | Manual orders / edits |
| POST / PATCH | `/products`, `/products/:pid` | Manual products / edits |
| POST | `/members` | Invite a member (owner only) |
| POST | `/billing/checkout` | Stripe Checkout for a plan |
| POST | `/billing/portal` | Stripe customer portal |
| GET | `/export` | Export the business as JSON (credentials not included) |

State changes go through `repo.mutate()` with optimistic locking; clients re-fetch or listen on `/events`.
