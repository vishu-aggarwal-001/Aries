# Launching and selling Aries (from LAUNCH.md)

Not legal advice; get a lawyer for contracts.

1. **Name and company**: trademark search for "Aries" (USPTO, EUIPO), app stores, domains; register the domain; form a company so liability isn't personal.
2. **Legal docs** (agents take real actions): Terms of Service (customers authorize agents within their rules, are responsible for those rules, AI can be wrong, liability limits); Privacy Policy (customers' customer data goes to Anthropic and connected apps); DPA for business customers (GDPR/UK GDPR; Anthropic and host as subprocessors); read Anthropic's Commercial Terms and Usage Policy.
3. **Accounts and keys**: Anthropic production key, raised rate limits, spend alert. Stripe: Starter/Growth/Scale prices, webhook `$PUBLIC_URL/api/stripe/webhook` for `checkout.session.completed` and `customer.subscription.*`, customer portal on. Shopify Partner public app with redirect `$PUBLIC_URL/api/oauth/shopify/callback` and **protected customer data** access (review takes weeks). Optional Shippo/Resend partner programs.
4. **Hosting**: Dockerfile on Fly.io/Render/Railway, managed Postgres with daily backups, every `.env.example` variable set, `SECRET_KEY` never changed, HTTPS only, error monitoring (e.g. Sentry), uptime check on `/api/health`.
5. **Google Play**: final application ID, build with `-PariesUrl`, own upload key, AAB, data safety form, account deletion in-app and on the web, no in-app purchase links without Play Billing.
6. **Pricing sanity**: `aiCreditUsd` per plan is the Anthropic cost cap per business per month; watch real usage in the first weeks; verify model prices in `engine/claude.ts` or override with `PRICES`. Haiku is cheapest.
7. **Before the first paying customer**: full flow on a Shopify dev store + Shippo test key; keep default rules conservative; write onboarding email and a help page per connector.

## Releasing a new version
1. `cd server && npm test && npm run typecheck`; `cd web && npm run build`.
2. Bump Android `versionCode`/`versionName` in `android/app/build.gradle.kts` if the shell changed; build the AAB/APK.
3. Deploy the container; check `/api/health`; watch logs for heartbeat errors.
4. Commit, push to GitHub, attach the APK to a GitHub Release for direct download.
