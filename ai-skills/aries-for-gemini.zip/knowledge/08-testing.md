# Testing Aries

```bash
cd server && npm test        # vitest, end-to-end
cd server && npm run typecheck
cd web && npm run build      # typechecks the web app too
```

## What the suite covers (server/test/aries.test.ts)
- Signs up, founds a store business with a crew and a daily brief
- Other users cannot see the business (tenancy)
- Connects Shopify, imports orders and products, turns them into work
- Ops agent quotes rates, label purchase waits for approval, then ships end to end
- "Never" rules block actions outright
- Works with any MCP server: reads run, writes need approval
- Refuses customer-supplied URLs that point inside the network (SSRF)
- Verifies Stripe and Shopify signatures and upgrades the plan
- Pauses the crew when the month's AI credit is used up
- Deleting an account removes the business, its secrets and the login
- Share-to-Aries routes customer messages to support

## Fakes (no network, no API spend)
- `setFakeFetch(fn)` in `connectors/base.ts`: every connector `http()` call goes to `fn(url, init)` returning `{ status, body, headers? }`. Route by URL host/path to simulate Shopify, Shippo, Stripe, MCP, etc.
- `setFakeClaude(fn)` in `engine/claude.ts`: receives the Messages API request body and returns a response (`content` with `tool_use` blocks, `stop_reason`, `usage`). Script an agent by returning tool calls in sequence, ending with `end_heartbeat`.
- `npm run demo` uses the same fakes for a clickable demo.

## Writing a new test
1. Boot an app with an embedded DB in a temp folder (see the suite's setup), sign up, found a business.
2. Install fakes, add a connection, trigger a heartbeat (`engine.heartbeat(bid, agentId, "test")`) or call the API.
3. Assert on State (tasks, actions ledger, approvals, orders) and on what the fake fetch received.
Keep each test independent; reset fakes after each.

## Manual check before a release
Run the full flow against a Shopify development store and a Shippo test key: order → rates → label → fulfill → email.
