# Connectors

## Built in
| Type | Label | Group | Agent tools | Notes |
|---|---|---|---|---|
| `shopify` | Shopify | Store | `search_orders`, `get_order`, `fulfill_order`, `update_product`, `add_order_note` | OAuth ("Connect with Shopify") or admin token. Syncs orders/products. Needs protected customer data access for names/addresses. |
| `woocommerce` | WooCommerce | Store | `get_order`, `complete_order`, `update_product` | Site URL + REST key/secret. Syncs. |
| `stripe` | Stripe | Payments | `recent_payments`, `balance`, `create_payment_link`, `refund` | The business's own Stripe (not Aries's billing account). |
| `shippo` | Shippo | Shipping | `get_rates`, `buy_label` (PDF 4x6), `track` | Label purchase is "Spend money". |
| `email` | Email (Resend) | Messaging | `send_email` | "Message customers". |
| `webhook` | Zapier / Make / webhook | Universal | `send_event` | Owner defines event names; writes are "Other apps". |
| `mcp` | MCP server | Universal | every tool the server lists | Tools are discovered at connect/refresh. Reads run; writes need approval. |
| `api` | Any REST API | Universal | `get`, `send` (POST/PUT/PATCH/DELETE) | Base URL + auth header. |

Connections: add (`POST /api/b/:bid/connections`), remove, refresh (re-validate/re-sync), and the owner can invoke a tool directly (`POST /tools/:name`).

## Security
- Credentials are AES-256-GCM encrypted in a separate table; agents and browsers never see them.
- Customer-supplied URLs go through `assertPublicUrl`: https only (unless `ALLOW_HTTP_CONNECTORS=1`), no localhost/.local/.internal/metadata hosts, DNS-resolved addresses must not be private (10/8, 127/8, 169.254/16, 172.16/12, 192.168/16, 100.64/10, ::1, fc/fd, fe80). Redirects are not followed for user URLs.
- Shopify OAuth state is stored in `oauth_states`; Stripe and Shopify webhooks/callbacks are signature-verified.

## Adding a connector
1. Create or extend a file in `server/src/connectors/` exporting a `ConnectorDef`:
   ```ts
   export const myapp: ConnectorDef = {
     type: "myapp", label: "My App", blurb: "One line for the catalog", group: "Messaging",
     fields: [{ key: "apiKey", label: "API key", secret: true }, { key: "account", label: "Account ID" }],
     docsUrl: "https://…",
     async connect(ctx) { /* call a cheap endpoint to validate; return { info } */ return {}; },
     tools: () => [
       { name: "list_things", description: "…", input_schema: obj({ q: str("Search") }), category: null },
       { name: "send_thing", description: "…", input_schema: obj({ to: str("…") }, ["to"]), category: "customer_message",
         summary: i => `Send thing to ${i.to}` },
     ],
     async execute(ctx, tool, input) { /* use http(), ctx.secrets.apiKey */ return { text: "result for the agent" }; },
     async sync(ctx) { return { orders: [], products: [] }; }, // optional
   };
   ```
2. Add it to `CONNECTORS` in `server/src/connectors/index.ts`.
3. Use `http()` from `base.ts` (timeouts, error messages, test fakes). Pass `userUrl: true` for any URL the customer typed.
4. Pick the right `category` for each write (`customer_message`, `spend`, `refund`, `store_update`, `payment_link`, `external_write`); give money tools an `amountUsd(input)` so $ limits work; give writes a clear `summary` (it's what the owner approves).
5. Add tests with `setFakeFetch` (see 08-testing). The web app picks the connector up from `/api/catalog` automatically.
