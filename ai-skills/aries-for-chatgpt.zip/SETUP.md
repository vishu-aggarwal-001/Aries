# Aries skill library for ChatGPT (custom GPT)

## Setup
1. In ChatGPT, open **GPTs → Create**, then the **Configure** tab.
2. Name: `Aries Skill Library`. Description: `Run, build, test and release Aries, and act as any Aries crew agent.`
3. Paste all of `INSTRUCTIONS.txt` into **Instructions**.
4. Under **Knowledge**, upload every file in `knowledge/`.
5. Turn on **Code Interpreter** (lets it open repo zips you upload) and save.

No GPT builder on your plan? Make a **Project** instead: paste `INSTRUCTIONS.txt` into the project instructions and add the `knowledge/` files.

## Files in this zip
- `INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
