# Aries skill library for Claude Code

Unzip into the root of your Aries repo (it adds `CLAUDE.md` and `.claude/skills/aries-skill-library/`). Claude Code picks the skill up automatically; you can also type `/aries-skill-library`.
