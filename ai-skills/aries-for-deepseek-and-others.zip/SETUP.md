# Aries skill library for DeepSeek, Meta AI, Copilot and any other chatbot

Most other chatbots don't keep custom instructions or files between chats, so use the all-in-one file.

## Setup (any AI)
1. Start a new chat.
2. Upload `ARIES_ALL_IN_ONE.md` (or paste its contents if uploads aren't supported).
3. Say: "Use this as your Aries skill library for this chat." Then ask your question.

If the app does have saved instructions (Microsoft Copilot, Meta AI, Poe bots, HuggingChat assistants…), paste `INSTRUCTIONS.txt` there and attach the `knowledge/` files or `ARIES_ALL_IN_ONE.md`.

## Files in this zip
- `INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
