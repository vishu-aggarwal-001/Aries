# Aries skill library for Mistral Le Chat (Agent / Library)

## Setup
1. In Le Chat, open **Libraries**, create one named `Aries`, and upload every file in `knowledge/`.
2. Create an **Agent** (or Project) named `Aries Skill Library`, paste all of `INSTRUCTIONS.txt` into its instructions, and attach the `Aries` library.
3. Chat with that agent.

## Files in this zip
- `INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
