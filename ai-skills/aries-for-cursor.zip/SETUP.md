# Aries skill library for Cursor

Unzip into the root of your Aries repo. `aries.mdc` always applies; the other rules are pulled in by Cursor's agent when their description matches the task, or mention one with `@aries-06-connectors`.
