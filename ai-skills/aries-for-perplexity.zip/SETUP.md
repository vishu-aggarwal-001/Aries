# Aries skill library for Perplexity (Space)

## Setup
1. In Perplexity, create a **Space** named `Aries Skill Library`.
2. Paste all of `INSTRUCTIONS.txt` into the Space's **instructions**.
3. Upload every file in `knowledge/` to the Space.
4. Ask questions inside the Space. For code questions, choose a reasoning model.

## Files in this zip
- `INSTRUCTIONS.txt`: paste into the instructions box (3597 characters).
- `knowledge/`: the 10 reference files to upload.
- `ARIES_ALL_IN_ONE.md`: everything in one file. Use it if file uploads are limited (upload just this one), or paste it at the start of any chat.

## Try it
- "How do I run the Aries demo on my laptop?"
- "Add a Square connector to Aries."
- "My Ops agent didn't buy a label. Why?"
- "Act as June and reply to this customer: …"
