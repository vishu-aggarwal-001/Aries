# Aries skill library for OpenAI Codex (and any tool that reads AGENTS.md)

Unzip into the root of your Aries repo. Codex reads `AGENTS.md` automatically and the skill lives in `.agents/skills/`. To use the skill in every project, also copy `.agents/skills/aries-skill-library` into `~/.codex/skills/`. Other tools that read `AGENTS.md` (Jules, Amp, Gemini CLI if you rename it to `GEMINI.md`, etc.) work too.
